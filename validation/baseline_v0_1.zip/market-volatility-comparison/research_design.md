# 研究設計 v0.1

作成日：2026年11月5日。既存研究のデータと期間分割を引き継ぐ、RQ1〜RQ3の基礎比較です。RQ4は設計案として分けます。

## 1. 研究目的の表現

本研究は、S&P 500の日次対数リターンについて、3種類の点予測モデルと3種類の予測区間構築法を比較し、市場のボラティリティに応じた精度、経験的Coverage、区間幅の違いを明らかにする。

「最適な手法を決定する」よりも、「対象データ、比較候補、評価基準の範囲内で、どの組み合わせがどの市場環境に適していたかを検討する」と表現する。過去のTestで最小値だった手法が、将来も最適であるとは限らない。

## 2. 予測時点とデータ分割

リターンは `r_t = 100 × log(P_t / P_(t-1))` とする。前営業日の引け後を予測時点とし、その時点で既知の `r_(t-1)` と `VIX_(t-1)` までを使う。

| データ | 期間 | 用途 |
| --- | --- | --- |
| Training | 2017–2018年、502日 | Historical MeanとAR(1)の係数推定 |
| Calibration | 2019年、252日 | Fixed CPの分位点、Normalの標準偏差、Rollingの初期履歴 |
| Test | 2020-01-02〜2026-10-28、1,715日 | 点予測と予測区間の評価 |

日付はS&P 500の観測日にそろえ、VIXもその日付に結合する。VIXを当日値で分類すると予測時点に未知の情報を使うため、必ず前営業日値を用いる。価格は配当込み指数への置き換えなどをせず、元のCSVをそのまま使う。

## 3. 点予測モデル

| モデル | 予測式 | Trainingで求めるもの |
| --- | --- | --- |
| Random Walk | `r_hat_t = 0` | なし |
| Historical Mean | `r_hat_t = mean(r_train)` | Training期間の平均 |
| AR(1) | `r_hat_t = beta0 + beta1 × r_(t-1)` | 切片と1日前のリターンの係数 |

Random Walkは**価格の対数値がドリフトなしのランダムウォークに従う**という基準モデルなので、リターン予測は0となる。「リターンの翌日予測を前日のリターンにする」という別のモデルとは区別する。

AR(1)は元研究の切片付きOLSと同一である。今回の変更は、元のAR(1)を残して、0予測と過去平均の基準モデルを追加することに当たる。全モデルの係数をTraining後に固定して、まず区間の作り方による差を比較する。

## 4. 予測区間

各モデルの符号付き誤差を `e_t = r_t - r_hat_t`、Conformalのスコアを `s_t = abs(e_t)` とする。

| 方法 | 区間 | 誤差に使う期間 | Test中の更新 |
| --- | --- | --- | --- |
| Fixed CP | `r_hat_t ± q_fixed` | Calibration全体 | なし |
| Rolling CP | `r_hat_t ± q_t` | tより前の直近252営業日 | 毎営業日 |
| Normal | `r_hat_t ± z_(1-alpha/2) × sigma_cal` | Calibration全体 | なし |

Conformalの半幅は `k = ceil((n + 1) × (1 - alpha))` とし、小さい順に並べたスコアのk番目を使う。補間する通常の分位点とは区別する。kがnを超える場合は無限大とするが、今回のn=252、alpha=0.10では発生しない。

Rollingは、まず当日の幅を過去のスコアから決め、その後に当日の実現誤差を履歴へ追加する。Test初日は、FixedとRollingの参照データが同じなので半幅も一致する。

Normalの `sigma_cal` はCalibrationの符号付き誤差の標本標準偏差（ddof=1）とする。alpha=0.10ではzは約1.644854である。誤差平均を0と仮定し、予測値の中心は変更しない。実際のCalibration誤差の平均もCSVに記録する。

これは新しい観測値のばらつきを表す正規近似の予測区間であり、平均の信頼区間ではない。したがって `sigma / sqrt(n)` は使わない。誤差の非正規性、分散の時間変化、推定パラメータの不確実性を十分には扱わず、厳密な有限標本の回帰予測区間ではない。

Fixed CP対Normalは、同じ固定Calibration期間で、経験分位点と正規近似を比べる。Fixed CP対Rolling CPは、同じConformal方式で履歴の更新を比べる。Rolling CP対固定Normalには、分布仮定と更新方法の両方の違いが含まれるため、「Conformalが正規分布より優れている」とだけ結論しない。必要に応じ、同じ直近252日の誤差を使うRolling Normalを追加の感度分析にする。

## 5. Research Questionsと評価

| RQ | 問い | 主な評価 |
| --- | --- | --- |
| RQ1 | 比較した3モデルのうち、各市場区分で点予測の誤差が小さいのはどれか | MAE・RMSE |
| RQ2 | どの組み合わせが、Coverage・Width・外れた際の大きさの点で良い結果を示すか | Coverage・Width・Interval Score |
| RQ3 | 非高VIX時と高VIX時で、その結果がどのように異なるか | 市場区分別評価、年別診断 |

点予測は3モデルを比較し、予測区間は9通りを比較する。Coverageが高いだけでも、幅が狭いだけでも「最良」としない。Coverageの90%からのずれを確認し、その上で幅とInterval Scoreを見る。

Interval Scoreは次の式で計算し、小さいほど良いとする。

`IS = (U - L) + (2/alpha) × max(L - r, 0) + (2/alpha) × max(r - U, 0)`

この指標は幅と区間外の誤差を合わせて評価する。単独で90% Coverageの達成を意味するものではないので、Coverage・上下それぞれの外れ率も併記する。

現段階のTestは記述的比較に使っている。ここで手法や設定を選んだ場合、この同じTestの数値を未使用の最終評価結果とは呼ばない。将来の予測性能や適応的な手法選択を評価する場合は、新しい期間の確保、または時系列順のValidationと最終Testの分割が必要になる。

## 6. RQ4：発展研究の設計案

How Does the Inclusion of High-Volatility Periods in Training and Calibration Data Affect Forecast Accuracy and Prediction Interval Performance?

既定のデータ分割では、Trainingの高VIX日は5日（約1.00%）、Calibrationでは0日である。この1つの分割だけでは、含有割合の効果を比較できない。

まずは複数の予測開始日を決め、各開始日より過去のデータだけでTrainingとCalibrationを作り、次の一定期間を評価する実験が考えられる。各開始日で9通りに同じTest日を使う。候補の開始日、Training長、Calibration長、評価日数は、使用可能なデータ数と高VIXエピソード数を確認してから先に決める。

| 要因 | 比較するときに固定するもの | 記録するもの |
| --- | --- | --- |
| Trainingの高VIX割合 | 同一の開始日ではCalibrationとTest、Training長 | 係数、MAE・RMSE、Trainingの高VIX日数と位置 |
| Calibrationの高VIX割合 | 同一の開始日ではTrainingとTest、Calibration長 | Coverage・Width・IS、Calibrationの高VIX日数と位置 |
| Calibrationの長さ | 同一の開始日ではTrainingとTest | 高VIX割合、最後の高VIX日からの経過日数 |
| Rolling Window | 予測モデル、開始時点、評価日 | 63・126・252日などの区間性能と履歴構成 |

高VIX割合、観測の新しさ、危機の大きさは自然の時系列では同時に変わる。任意の割合を作るために日付を選び直すと、連続期間の比較とは別の設計になる。単に期間をずらした結果を、高VIX割合だけの因果効果と解釈しない。AR(1)の説明変数も、元データの前営業日のリターンを保ち、選び直した標本の直前行から作り直さない。

Random Walkは学習パラメータを持たないので、Training期間の変更による点予測の差は発生しない。Training構成の比較は主にHistorical MeanとAR(1)について行う。

**RQ4の比較条件と実装は今回まだ確定していない。** 基礎比較で良かった1つだけを同じTestで選び、同じTestで再び設定を最適化すると選択の影響が重なるため、追加実験のValidationと最終評価を分けて考える。

## 7. 統計的な解釈と次の検証

Conformalの通常の有限標本Coverage保証は、交換可能性などの条件に依存する。金融時系列で、その条件が自動的に成立するとは扱わない。Rollingによる更新も、各VIX区分で90% Coverageを保証するものではない。本研究は、これらの環境における経験的な挙動を比較する。

次の段階では、同じ連続日付ブロックを全手法に使うpaired moving block bootstrapで指標の差の不確実性を検討する。高VIX日だけを先に取り出して無作為抽出するのではなく、全時系列とVIX区分を一緒に抽出する。Block長5・10・20などの感度を確認し、金融データの非定常性の下で区間が近似的であることも説明する。今回の実装ではBootstrapによる信頼区間や有意差判定はまだ計算していない。

## 参考資料

- Hyndman, R. J. & Athanasopoulos, G. *Forecasting: Principles and Practice*, Chapter 5. 基準予測、正規近似区間、誤差評価：[本文](https://otexts.com/fpp3/toolbox.html)
- Barber, R. F., Candès, E. J., Ramdas, A. & Tibshirani, R. J. (2023). *Conformal Prediction Beyond Exchangeability*. Annals of Statistics. 交換可能性と分布変化：[著者公開版](https://www.stat.cmu.edu/~ryantibs/papers/nexcp.pdf)
- Gneiting, T. & Raftery, A. E. (2007). *Strictly Proper Scoring Rules, Prediction, and Estimation*. JASA. Interval Score：[著者公開版](https://sites.stat.washington.edu/people/raftery/Research/PDF/Gneiting2007jasa.pdf)

これらは今回の定義と評価方法の根拠であり、網羅的な先行研究調査や新規性の証明ではない。
