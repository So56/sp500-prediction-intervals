"""分析コードとは分けて、再現性と時間順序を確認する。"""

import hashlib
import json
from pathlib import Path
import sys
from statistics import NormalDist

import numpy as np
import pandas as pd

project_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_dir / "Scripts"))
from intervals import conformal_halfwidth, rolling_halfwidths
from settings import ALPHA, METHODS, MODELS, WINDOW


reference_dir = project_dir / "validation" / "reference"
model_dir = project_dir / "outputs" / "modeling"
evaluation_dir = project_dir / "outputs" / "evaluation"
checks = []

# 新しい前処理が元の研究と一致するか
data = pd.read_csv(project_dir / "data" / "processed" / "analysis_dataset.csv")
old_data = pd.read_csv(reference_dir / "analysis_dataset.csv")
pd.testing.assert_frame_equal(data[old_data.columns], old_data, check_exact=False,
                              rtol=1e-12, atol=1e-12)
checks.append("Processed data match the original project.")

# AR(1)は元のOLSと同じモデルになっているか
coefficients = pd.read_csv(model_dir / "model_coefficients.csv").set_index("model")
old_coefficients = pd.read_csv(reference_dir / "ols_coefficients.csv")
np.testing.assert_allclose(
    coefficients.loc["ar1", ["intercept", "lag1_coefficient"]].to_numpy(),
    old_coefficients["estimate"].to_numpy(), rtol=1e-12, atol=1e-12,
)
train = data.loc[data["split"] == "training"]
np.testing.assert_allclose(coefficients.loc["historical_mean", "intercept"],
                           train["return_pct"].mean())
checks.append("Training-only coefficients and the original AR(1) match.")

predictions = pd.read_csv(model_dir / "point_predictions.csv")
assert predictions.loc[predictions["model"] == "random_walk", "prediction_pct"].eq(0).all()
intervals = pd.read_csv(model_dir / "prediction_intervals.csv")
test_dates = data.loc[data["split"] == "test", "date"].tolist()
assert len(intervals) == len(test_dates) * 9
assert not intervals.duplicated(["date", "model", "method"]).any()
for model in MODELS:
    for method in METHODS:
        part = intervals.loc[(intervals["model"] == model) & (intervals["method"] == method)]
        assert part["date"].tolist() == test_dates
        assert part["history_end"].lt(part["date"]).all()
        assert (part["lower"] <= part["upper"]).all()
        assert np.isfinite(part[["prediction_pct", "lower", "upper"]].to_numpy()).all()
        if method == "rolling":
            assert part["history_n"].eq(WINDOW).all()
            assert part["history_end"].eq(part["forecast_origin_date"]).all()
checks.append("All nine combinations use identical dates and past-only interval histories.")

# AR(1)の予測値・全日のFixed/ Rolling区間が元の研究と一致するか
old_intervals = pd.read_csv(reference_dir / "prediction_intervals.csv")
for method in ["fixed", "rolling"]:
    part = intervals.loc[(intervals["model"] == "ar1") & (intervals["method"] == method)]
    assert part["date"].tolist() == old_intervals["date"].tolist()
    for new_column, old_column in [
        ("prediction_pct", "prediction_pct"), ("halfwidth", f"{method}_halfwidth"),
        ("lower", f"{method}_lower"), ("upper", f"{method}_upper"),
    ]:
        np.testing.assert_allclose(part[new_column], old_intervals[old_column],
                                   rtol=1e-12, atol=1e-12)
checks.append("Every AR(1) Fixed/Rolling interval matches the original project.")

summary = pd.read_csv(evaluation_dir / "interval_summary.csv")
old_summary = pd.read_csv(reference_dir / "group_summary.csv")
for old in old_summary.loc[old_summary["method"].isin(["fixed", "rolling"])].itertuples():
    part = summary.loc[(summary["model"] == "ar1") & (summary["group"] == old.group)
                       & (summary["method"] == old.method)].iloc[0]
    np.testing.assert_allclose(part[["coverage", "width", "interval_score"]].to_numpy(float),
                               [old.coverage, old.width, old.interval_score],
                               rtol=1e-12, atol=1e-12)
checks.append("Regime summaries match the original project.")

# 順位の計算と、未来の誤差が過去の幅に影響しないことを確認する
assert conformal_halfwidth([9, 1, 7, 3, 5], 0.5) == 5
assert np.isinf(conformal_halfwidth([1, 2], 0.1))
for model in MODELS:
    part = predictions.loc[predictions["model"] == model]
    calibration = part.loc[part["split"] == "calibration", "score_abs"]
    test = part.loc[part["split"] == "test", "score_abs"].to_numpy()
    original = rolling_halfwidths(calibration, test, WINDOW, ALPHA)
    changed = test.copy()
    changed[10:] += 100
    altered = rolling_halfwidths(calibration, changed, WINDOW, ALPHA)
    np.testing.assert_array_equal(original[:11], altered[:11])
    assert not np.array_equal(original[11:], altered[11:])
    np.testing.assert_allclose(original[0], conformal_halfwidth(calibration, ALPHA))
checks.append("Finite-sample rank and future-error perturbation checks pass for all models.")

# Normalの幅と、各方法に共通の予測中心を確認する
for model in MODELS:
    calibration = predictions.loc[(predictions["model"] == model)
                                  & (predictions["split"] == "calibration")]
    normal = intervals.loc[(intervals["model"] == model) & (intervals["method"] == "normal")]
    expected = NormalDist().inv_cdf(1 - ALPHA / 2) * calibration["error_pct"].std(ddof=1)
    np.testing.assert_allclose(normal["halfwidth"], expected, rtol=1e-12, atol=1e-12)
np.testing.assert_allclose((intervals["lower"] + intervals["upper"]) / 2,
                           intervals["prediction_pct"], rtol=1e-12, atol=1e-12)
checks.append("Normal half-widths use calibration errors and all intervals share their model's center.")

# 同じ日を基に集計し、点予測を9通りに重複計上していないか
points = pd.read_csv(evaluation_dir / "point_summary.csv")
assert len(points) == 9 and len(summary) == 27
assert points.loc[points["group"] == "overall", "n"].eq(len(test_dates)).all()
for row in summary.itertuples():
    np.testing.assert_allclose(row.coverage + row.lower_miss + row.upper_miss, 1)
checks.append("Point and interval evaluation counts and tail probabilities are consistent.")

result = {"passed": True, "checks": checks,
          "test_n": len(test_dates), "combinations": 9,
          "raw_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted((project_dir / "data" / "raw").glob("*.csv"))}}
source_hashes = json.loads((project_dir / "validation" / "source_hashes_before.json").read_text(encoding="utf-8-sig"))
for name, checksum in result["raw_sha256"].items():
    old = next(row for row in source_hashes if row["path"].replace("\\", "/") == f"data/raw/{name}")
    assert checksum == old["sha256"]
checks.append("Both raw input files are byte-identical to the original project.")
(project_dir / "validation" / "verification.json").write_text(
    json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
)
print(json.dumps(result, indent=2, ensure_ascii=False))
