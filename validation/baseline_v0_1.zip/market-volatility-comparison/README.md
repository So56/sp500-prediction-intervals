# 市場のボラティリティに応じた予測モデルと予測区間構築法の比較

Comparing Forecasting Models and Prediction Interval Methods Across Market Volatility Regimes

## 今回作成したもの

元の `fixed-vs-rolling-conformal` の生データをそのまま使う、独立した比較用プロジェクトです。3種類の点予測と3種類の予測区間、計9通りを計算します。元プロジェクトへの書き込みは行っていません。

本体のコードは、元の研究と同じように、データ読み込み、計算、CSV保存を上から順に書いています。日本語の短いコメントを付け、クラスや大きな共通処理、広範な例外処理は使っていません。時間順序や元の結果との一致を調べる処理は `validation/` に分けています。

研究の定義は [research_design.md](research_design.md)、今回の数値と考察は [reports/initial_results.md](reports/initial_results.md) にあります。

## 分析設定

| 項目 | 設定 |
| --- | --- |
| 予測対象 | 翌営業日のS&P 500日次対数リターン（%） |
| Training | 2017-01-03〜2018-12-31、502営業日 |
| Calibration | 2019-01-02〜2019-12-31、252営業日 |
| Test | 2020-01-02〜2026-10-28、1,715営業日 |
| 予測区間 | 90%、alpha = 0.10 |
| Rolling Window | 252営業日 |
| High-VIX | 予測日前営業日のVIXが30以上 |
| Non-high-VIX | 予測日前営業日のVIXが30未満 |

モデルの係数とHistorical Meanの平均は、Training期間で推定した値に固定します。Rollingで更新するのは区間の幅です。VIXは市場の分類だけに使い、モデルの説明変数には加えていません。

Normalは、各モデルのCalibration期間の符号付き誤差の標準偏差を使う、**固定の正規近似区間**です。有限標本の厳密な回帰予測区間とは区別しています。

## 実行方法

VS Codeでこのフォルダを開き、PowerShellで実行します。Python 3.13で動作確認しました。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe Scripts/run_all.py
```

1つずつ理解しながら実行する場合は、次の順に進めます。

| 順番 | スクリプト | 何をしているか |
| --- | --- | --- |
| 1 | `Scripts/01_prepare_data.py` | 生データの結合、対数リターンと前営業日の変数の作成、期間分割 |
| 2 | `Scripts/02_fit_models.py` | 3モデルの学習、CalibrationとTestの予測値・誤差の保存 |
| 3 | `Scripts/03_build_intervals.py` | モデルごとにFixed、Rolling、Normal区間を作成 |
| 4 | `Scripts/04_evaluate.py` | MAE、RMSE、Coverage、Width、Interval Scoreを集計 |
| 5 | `Scripts/05_make_figures.py` | 比較図をPNGとPDFで保存 |

例えば最初の段階だけを実行するには、次のコマンドを使います。

```powershell
.\.venv\Scripts\python.exe Scripts/01_prepare_data.py
```

`Scripts/settings.py` に分析設定、`Scripts/intervals.py` に2つの短い区間計算用関数をまとめています。`run_all.py` と各スクリプトを再実行すると、この新プロジェクト内の対応する出力が上書きされます。

検証は分析本体とは別に実行できます。

```powershell
.\.venv\Scripts\python.exe validation/verify_analysis.py
```

この検証は今回の既定設定を対象とします。`validation/reference/` は元研究の比較用コピーなので、設定を変えた実験では、元結果との一致を要求するチェックは適用しません。

## 主な出力

| 出力 | 内容 |
| --- | --- |
| `data/raw/` | 元研究と同じ2つのCSV。ダウンロードし直していません |
| `data/processed/analysis_dataset.csv` | 元研究と同じ前処理済みデータ |
| `outputs/modeling/model_coefficients.csv` | 3モデルの推定係数 |
| `outputs/modeling/point_predictions.csv` | Calibration・Testの点予測と誤差 |
| `outputs/modeling/prediction_intervals.csv` | 9通り×1,715日の予測区間と履歴期間 |
| `outputs/modeling/interval_settings.csv` | 固定半幅、Normalの標準偏差、Calibration誤差の平均など |
| `outputs/evaluation/point_summary.csv` | 3モデル×3市場区分のMAE・RMSE |
| `outputs/evaluation/interval_summary.csv` | 9通り×3市場区分の区間評価 |
| `outputs/evaluation/annual_summary.csv` | 年別の区間評価。2026年は10月28日まで |
| `outputs/evaluation/daily_evaluation.csv` | 日別の評価 |
| `outputs/figures/` | 点予測の精度、9通りの比較、AR(1)区間の時系列 |
| `validation/verification.json` | 再現性と時間順序の検証結果、生データのSHA-256 |

CSVのCoverageは0〜1、図と結果説明では%です。リターン、誤差、区間幅はリターンのパーセントポイント単位です。MAE・RMSEは区間の種類で変わらないため、3モデルについてだけ集計します。

## 完了した範囲と次の作業

RQ1〜RQ3の記述的な基礎比較を実装・実行しました。AR(1)＋Fixed／Rollingが元研究と一致することも確認済みです。現段階では、モデル間のわずかな差を統計的な優位性とは解釈しません。

RQ4、ブロックBootstrapによる不確実性評価、WindowやVIX閾値の感度分析、独立した期間でのモデル選択の検証は未実装です。次の実験は結果を見ながら都合よく設定せず、比較条件と評価基準を先に決めて追加します。
