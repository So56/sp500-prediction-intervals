# 初期分析結果：3モデル×3区間構築法

作成日：2026年11月5日。今回の結果は、指定した候補と期間における記述的比較です。手法間の差の信頼区間や有意差はまだ計算していません。

## 設定と実装の範囲

元研究の生データを同一のバイト列でコピーして使用しました。Trainingは2017–2018年の502日、Calibrationは2019年の252日、Testは2020年1月2日〜2026年10月28日の1,715日です。高VIXは前営業日のVIXが30以上の149日、非高VIXは1,566日です。

予測対象は日次対数リターン（%）、区間の目標Coverageは90%、Rolling Windowは252営業日です。モデル係数はTraining後に固定しています。Random Walkのリターン予測は0、NormalはCalibration誤差の標準偏差を使う固定の正規近似区間です。詳細は[研究設計](../research_design.md)にあります。

## 1. 点予測

| 市場区分 | モデル | 日数 | MAE | RMSE |
| --- | --- | --- | --- | --- |
| 全Test | Random Walk | 1715 | 0.8313 | 1.2716 |
| 全Test | Historical Mean | 1715 | 0.8297 | 1.2709 |
| 全Test | AR(1) | 1715 | 0.8289 | 1.2680 |
| 高VIX | Random Walk | 149 | 2.0954 | 2.9464 |
| 高VIX | Historical Mean | 149 | 2.0940 | 2.9452 |
| 高VIX | AR(1) | 149 | 2.0842 | 2.9308 |
| 非高VIX | Random Walk | 1566 | 0.7110 | 0.9720 |
| 非高VIX | Historical Mean | 1566 | 0.7094 | 0.9713 |
| 非高VIX | AR(1) | 1566 | 0.7095 | 0.9714 |

全TestではAR(1)のMAE・RMSEが3モデル中で最小でした。ただし、Random Walkに対する改善率はMAEが約0.28%、RMSEが約0.28%です。今回の数値だけでAR(1)が実質的・統計的に優れているとは判断できません。非高VIXではHistorical Meanがわずかに小さい誤差を示しました。

AR(1)の推定係数は切片0.022809、前営業日リターンの係数−0.014257です。予測値が0付近となるため、3モデルの点予測が似ていることは自然です。

![点予測の精度](../outputs/figures/point_accuracy.png)

## 2. 9通りの予測区間

Coverageは%、幅とInterval Scoreはリターンのパーセントポイント単位です。Interval Scoreは小さいほど良い指標ですが、最小でもCoverageが90%に達しているとは限りません。


### 全Test

| モデル | 区間構築法 | Coverage（%） | 平均幅 | Interval Score |
| --- | --- | --- | --- | --- |
| Random Walk | Fixed CP | 80.17 | 2.4668 | 6.2893 |
| Random Walk | Rolling CP | 90.32 | 3.7015 | 5.9214 |
| Random Walk | Normal（固定） | 81.05 | 2.5866 | 6.1779 |
| Historical Mean | Fixed CP | 79.88 | 2.4764 | 6.2788 |
| Historical Mean | Rolling CP | 90.20 | 3.7020 | 5.9285 |
| Historical Mean | Normal（固定） | 81.22 | 2.5866 | 6.1766 |
| AR(1) | Fixed CP | 79.83 | 2.4705 | 6.2692 |
| AR(1) | Rolling CP | 90.26 | 3.7131 | 5.9229 |
| AR(1) | Normal（固定） | 81.22 | 2.5835 | 6.1642 |

### 高VIX

| モデル | 区間構築法 | Coverage（%） | 平均幅 | Interval Score |
| --- | --- | --- | --- | --- |
| Random Walk | Fixed CP | 40.27 | 2.4668 | 24.7378 |
| Random Walk | Rolling CP | 65.77 | 4.5615 | 19.4679 |
| Random Walk | Normal（固定） | 40.27 | 2.5866 | 24.1422 |
| Historical Mean | Fixed CP | 39.60 | 2.4764 | 24.6452 |
| Historical Mean | Rolling CP | 66.44 | 4.5664 | 19.4497 |
| Historical Mean | Normal（固定） | 40.94 | 2.5866 | 24.0993 |
| AR(1) | Fixed CP | 40.27 | 2.4705 | 24.5022 |
| AR(1) | Rolling CP | 66.44 | 4.5871 | 19.3203 |
| AR(1) | Normal（固定） | 40.94 | 2.5835 | 23.9454 |

### 非高VIX

| モデル | 区間構築法 | Coverage（%） | 平均幅 | Interval Score |
| --- | --- | --- | --- | --- |
| Random Walk | Fixed CP | 83.97 | 2.4668 | 4.5340 |
| Random Walk | Rolling CP | 92.66 | 3.6196 | 4.6325 |
| Random Walk | Normal（固定） | 84.93 | 2.5866 | 4.4687 |
| Historical Mean | Fixed CP | 83.72 | 2.4764 | 4.5313 |
| Historical Mean | Rolling CP | 92.46 | 3.6197 | 4.6420 |
| Historical Mean | Normal（固定） | 85.06 | 2.5866 | 4.4713 |
| AR(1) | Fixed CP | 83.59 | 2.4705 | 4.5344 |
| AR(1) | Rolling CP | 92.53 | 3.6300 | 4.6482 |
| AR(1) | Normal（固定） | 85.06 | 2.5835 | 4.4723 |

全TestのInterval ScoreはRandom Walk＋Rolling CPが最小ですが、AR(1)＋Rolling CPとの差は約0.0015と小さい値です。一方、高VIXではAR(1)＋Rolling CPが最小です。したがって、1つの組み合わせを全市場で最良とする結論にはなりません。

AR(1)では、FixedからRollingにすると、全TestのCoverageが79.83%から90.26%、高VIXでは40.27%から66.44%へ上昇します。同時に平均幅も全Testで2.4705から3.7131、高VIXで2.4705から4.5871へ広がります。

高VIXでは9通りのどの方法も90% Coverageを達成していません。全Testの約90%という値には、非高VIX時の約92〜93%も含まれています。全体のCoverageだけで高VIX時の信頼性を評価しないことが重要です。

非高VIXではNormalのInterval ScoreがRollingより小さい結果ですが、Coverageは約85%です。これは「目標90%の信頼性を保った上で優れている」という意味ではありません。

Random WalkとHistorical MeanのNormalの幅が等しいのは、両者の誤差が定数分だけずれており、標本標準偏差が変わらないためです。

![9通りの比較](../outputs/figures/nine_combinations.png)

## 3. 時間的な変化

Rollingの幅は、最近の誤差を取り込んで変化します。大きな変動が直近252日の履歴に残る間は、幅が広い状態が続く場合があります。下のCoverageは直近126営業日の集計であり、高VIX日だけの集計ではありません。

![AR(1)の区間幅と直近Coverage](../outputs/figures/ar1_width_and_coverage.png)

## 4. RQごとの暫定的な回答

| RQ | この分析から言えること |
| --- | --- |
| RQ1 | 全Testと高VIXではAR(1)、非高VIXではHistorical Meanの誤差が最小。ただしモデル間の差は小さい |
| RQ2 | 全TestのIS最小はRandom Walk＋Rolling、高VIXのIS最小はAR(1)＋Rolling。Coverageと幅も併せて判断が必要 |
| RQ3 | 高VIXでは点予測の誤差が大きくなり、全手法のCoverageが低下。Rollingは固定区間よりCoverageを改善したが、目標90%には届かなかった |
| RQ4 | 未検証。Trainingの高VIX日は5日、Calibrationは0日なので、構成の異なる期間を用いた追加実験が必要 |

## 5. 実装の検証

以下のチェックに合格しました。

- 新しい前処理済みデータが元研究のデータと一致。
- Trainingだけで推定した係数を使用し、AR(1)の係数が元研究と一致。
- 9通りすべてが同じ1,715日を評価し、区間の履歴は予測日より前。
- AR(1)＋Fixed／Rollingの全評価日の予測値・半幅・上下限が元研究と一致。
- AR(1)の全体・高VIX・非高VIXのCoverage、Width、ISが元研究と一致。
- Conformalの順位計算、全モデルの初日の幅の一致、未来の誤差を変更しても過去のRolling幅が変わらないことを確認。
- 点予測を区間ごとに重複計上せず、Coverageと上下の外れ率の合計が1であることを確認。
- Normalの半幅と、全区間が各モデルの予測値を中心としていることを確認。
- 元プロジェクトの研究関連80ファイルのSHA-256を作業前後で比較し、変更0件を確認。

数値の一致は相対・絶対許容誤差1e-12で確認しています。これは元の計算との一致と今回の実装上の検証であり、金融時系列におけるConformalの理論保証の成立を証明するものではありません。

## 6. 次の段階

1. この版の各スクリプトを順に読み、特にRandom Walkの定義、Normalの仮定、Rollingの更新順序を理解する。
2. 研究上の比較基準と、Validation・最終Testの使い分けを確定する。今回見たTest上の最小値を、そのまま将来の最良手法とは扱わない。
3. 必要な比較に絞って、手法間の差のpaired moving block bootstrapと感度分析を追加する。現時点では有意差を主張しない。
4. RQ4では、期間の長さ、観測の新しさ、共通の評価日を考慮して高VIXの割合・位置を比較する。市場データの構成と性能の関連を調べる設計とし、割合だけの因果効果とは解釈しない。

Fixed CPと固定Normalの比較は、同じCalibration期間における構築方法の比較です。Rolling CPと固定Normalの比較は、更新方法の違いも含むので、正規分布の仮定だけの影響とは言えません。

## 生データの一致確認

| ファイル | SHA-256 |
| --- | --- |
| SP500.csv | 49faa5a4f87574084a5e525e44013bad74e831947c2cc98b8031e87508d0d6b9 |
| VIXCLS.csv | b70f9750ac54ea6e89348b89f06178b9c053ed4238f808f6ca22d175a19cb5c6 |

元のファイルをコピーして使用し、新しいデータの取得・価格系列の置換・期間の延長は行っていません。
