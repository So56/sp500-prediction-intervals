from pathlib import Path
import subprocess
import sys


# 同じPython環境で、上から順に実行する
script_dir = Path(__file__).resolve().parent
scripts = [
    "01_prepare_data.py",
    "02_fit_models.py",
    "03_build_intervals.py",
    "04_evaluate.py",
    "05_make_figures.py",
]
for script in scripts:
    print(f"\n実行: {script}", flush=True)
    subprocess.run([sys.executable, str(script_dir / script)], check=True)
print("\n分析が完了しました。")
