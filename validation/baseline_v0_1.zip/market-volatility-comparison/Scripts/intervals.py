import math

import numpy as np


def conformal_halfwidth(scores, alpha):
    # 補間せず、有限標本補正を含む順位のスコアを選ぶ。
    k = math.ceil((len(scores) + 1) * (1 - alpha))
    if k > len(scores):
        return np.inf
    return np.sort(scores)[k - 1]


def rolling_halfwidths(calibration_scores, test_scores, window, alpha):
    history = list(calibration_scores)
    widths = []
    for score in test_scores:
        # 当日の誤差を追加する前に、過去の誤差だけで幅を決める。
        widths.append(conformal_halfwidth(history[-window:], alpha))
        history.append(score)
    return np.array(widths)
