import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from settings import ALPHA, GROUPS, METHODS, MODELS, project_dir


evaluation_dir = project_dir / "outputs" / "evaluation"
figure_dir = project_dir / "outputs" / "figures"
figure_dir.mkdir(parents=True, exist_ok=True)
point_summary = pd.read_csv(evaluation_dir / "point_summary.csv")
summary = pd.read_csv(evaluation_dir / "interval_summary.csv")
daily = pd.read_csv(evaluation_dir / "daily_evaluation.csv", parse_dates=["date"])
model_labels = ["Random Walk", "Historical Mean", "AR(1)"]
method_labels = ["Fixed CP", "Rolling CP", "Normal (fixed)"]
group_labels = ["All Test", "High VIX", "Non-high VIX"]
colors = ["#377eb8", "#e69f00", "#009e73"]
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})


def save_figure(fig, name):
    fig.tight_layout()
    fig.savefig(figure_dir / f"{name}.png", dpi=180)
    fig.savefig(figure_dir / f"{name}.pdf")
    plt.close(fig)


# 点予測の精度
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
positions = np.arange(len(MODELS))
for ax, metric in zip(axes, ["mae", "rmse"]):
    for g, (group, label) in enumerate(zip(GROUPS, group_labels)):
        values = point_summary.loc[point_summary["group"] == group].set_index("model")
        ax.bar(positions + (g - 1) * 0.24, values.reindex(MODELS)[metric],
               width=0.24, label=label, color=colors[g])
    ax.set_xticks(positions, model_labels)
    ax.set_ylabel(f"{metric.upper()} (return pp)")
axes[0].legend()
save_figure(fig, "point_accuracy")

# 9通りの結果。Coverageの色は90%からのずれを表す。
fig, axes = plt.subplots(3, 3, figsize=(12, 10))
for g, (group, group_label) in enumerate(zip(GROUPS, group_labels)):
    part = summary.loc[summary["group"] == group]
    for j, metric in enumerate(["coverage", "width", "interval_score"]):
        ax = axes[g, j]
        values = part.pivot(index="model", columns="method", values=metric)
        values = values.reindex(index=MODELS, columns=METHODS).to_numpy()
        if metric == "coverage":
            display = values * 100
            ax.imshow((values - (1 - ALPHA)) * 100, cmap="RdBu", vmin=-35, vmax=35)
            title = "Coverage (%) | target 90"
        else:
            display = values
            ax.imshow(values, cmap="Blues", vmin=0)
            title = "Width (return pp)" if metric == "width" else "Interval score (lower is better)"
        for i in range(3):
            for k in range(3):
                ax.text(k, i, f"{display[i, k]:.2f}", ha="center", va="center",
                        bbox={"facecolor": "white", "alpha": 0.85, "edgecolor": "none"})
        ax.set_xticks(range(3), method_labels, rotation=15)
        ax.set_yticks(range(3), model_labels)
        ax.set_title(f"{group_label}: {title}", fontsize=10)
save_figure(fig, "nine_combinations")

# AR(1)の幅と直近126営業日のCoverage
fig, axes = plt.subplots(2, 1, figsize=(11, 6), sharex=True)
for method, label, color in zip(METHODS, method_labels, colors):
    part = daily.loc[(daily["model"] == "ar1") & (daily["method"] == method)].sort_values("date")
    axes[0].plot(part["date"], part["width"], label=label, color=color, linewidth=1)
    axes[1].plot(part["date"], part["covered"].rolling(126).mean() * 100,
                 color=color, linewidth=1)
axes[0].set_ylabel("Width (return pp)")
axes[0].legend()
axes[0].set_title("AR(1): interval width and recent coverage")
axes[1].axhline((1 - ALPHA) * 100, color="gray", linestyle="--")
axes[1].set_ylabel("126-session coverage (%)")
save_figure(fig, "ar1_width_and_coverage")
print("図を保存しました。")
